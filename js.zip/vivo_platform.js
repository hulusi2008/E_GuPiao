function VOgamePlatform() {
    console.log("vivo平台初始化！！")
    this.isOpenVibration=true;
    // qg.initAdService({
    //     appId: "30208013",
    //     isDebug: false,
    //     success: function (res) {
    //         console.log("广告初始化success");
    //     },
    //     fail: function (res) {
    //         console.log("广告初始化fail:" + res.code + res.msg);
    //     },
    //     complete: function (res) {
    //         console.log("广告初始化complete");
    //     }
    // })
}

VOgamePlatform.prototype = {
    constructor: VOgamePlatform,
    /**
       * 微信登陆。
       * 获取code。
       */
    login: function (cb) {
        // qg.login({
        //     success: function (res) {
        //         console.log('登录成功',res);
        //     },

        //     fail: function (res) {
        //         console.log('登录失败：',res);
        //     }
        // });
    },

    /**
  * 获取小游戏启动参数
  */
    launchInfo: function () {
        // return qg.getLaunchOptionsSync();
    },

    //获取玩家信息
    getUserInfo: function () {

    },

    //加载
    startLoading: function (_callback) {

    },
    onLoading: function (_percent) {

    },

    destroyButton: function () {

    },

    /**
    * 微信授权窗口
    * 透明的按钮，覆盖到某个节点上(通常是开始按钮)。
    * @param rect  覆盖的节点区域
    * @param cb  回调 
    */
    authorize: function (rect, cb) {

    },

    /**
     *  是否授权获取用户信息
     */
    isAuthorize: function (cb) {

    },

    hideAuthenticLoginBtn: function () {

    },

    //投诉建议按钮
    createFeedbackButton: function (_btnVect) {

    },

    //亮屏
    onShow: function (_callback) {

    },
    //黑屏
    onHide: function (_callback) {

    },

    //取两个数之间的随机数
    GetRandomNum: function (Min, Max) {

    },

    //分享
    onShare: function (_callback) {

    },

    //跳转小程序
    navigateToMiniProgram: function (_data) {

    },
    setLoadingProgress: function (value)  {
        qg.setLoadingProgress({
            progress: value
        });
    },
    loadingComplete: function () {
        // qg.loadingComplete({
        //     success:function(res)
        //     {
        //         console.log("加载成功",res)
        //     },
        //     fail:function(err)
        //     {
        //         console.log("加载失败",err)
        //     },
        //     complete:function(res){
        //         console.log("加载完成",res)
        //     }
        // })
    },


    createBannerAd: function (_adUnitId, func) {
        // if (this.bannerAd == null) {
        console.log("创建banner广告")
        let bannerAd = qg.createBannerAd({
            posId: _adUnitId,
            style: {}
        });
        let adshow = bannerAd.show();
        // 调用then和catch之前需要对show的结果做下判空处理，防止出错（如果没有判空，在平台版本为1052以及以下的手机上将会出现错误）
        adshow && adshow.then(() => {
            console.log("banner广告展示成功");
        }).catch((err) => {
            switch (err.code) {
                case 30003:
                    console.log("新用户7天内不能曝光Banner，请将手机时间调整为7天后，退出游戏重新进入")

                    break;
                case 30009:
                    console.log("10秒内调用广告次数超过1次，10秒后再调用")

                    setTimeout(() => {
                        show()
                    }, 10000);
                    break;
                case 30002:
                    console.log("加载广告失败，重新加载广告")
                    setTimeout(() => {
                        //   retryShow()
                    }, 10000);
                    break;
                default:
                    // 参考 https://minigame.vivo.com.cn/documents/#/lesson/open-ability/ad?id=广告错误码信息 对错误码做分类处理
                    console.log("banner广告展示失败")
                    console.log(err)
                    break;
            }
        });
        this.bannerAd = bannerAd;
        return bannerAd;
        // }
    },
    closeBannerAd: function () {
        console.log("调用了clear banner！！！");
        if (!this.bannerAd) return;
        console.log("clear了banner！！！");
        var addestroy = this.bannerAd.destroy();
        // 调用then和catch之前需要对show的结果做下判空处理，防止出错（如果没有判空，在平台版本为1052以及以下的手机上将会出现错误）
        addestroy && addestroy.then(() => {
            console.log("banner广告销毁成功");
        }).catch(err => {
            console.log("banner广告销毁失败", err);
        });
        this.bannerAd = null;

    },

    setBannerVisible: function (visible) {
        if (!this.bannerAd) return;
        if (visible) {
            this.bannerAd.show();
            console.log("show!!!!!!!!!!!!!!!")
        }
        else {
            this.bannerAd.hide();
            console.log("hide!!!!!!!!!!!!!!!")
        }
    },

    //视频广告 preload 是否预加载，预加载不播放视频
    createRewardedVideoAd: function (_adUnitId, _callback, preload) {
        if (typeof (window["qg"].createRewardedVideoAd) == "undefined") {
            console.log("要真机调试才能测试头条的激励视频！！");
            return;
        }
        var videoAd = qg.createRewardedVideoAd({ posId: _adUnitId });
        if (videoAd) {
            videoAd.load();
            videoAd.onLoad(() => {
                let adshow = videoAd.show(console.log("激励广告展示成功"));
                adshow && adshow.catch(err => {
                    console.log("激励广告展示失败" + JSON.stringify(err))
                })
            })
            var closeCallback = function (res) {

                // 用户点击了关闭广告按钮
                if (res && res.isEnded) {
                    // 正常播放结束，可以下发游戏奖励
                    _callback && _callback(true);
                    console.log("正常播放结束，可以下发游戏奖励")
                }
                else {
                    // 播放中途退出，不下发游戏奖励
                    _callback && _callback(false);
                    console.log("播放中途退出，不下发游戏奖励")
                }
                videoAd.offClose(closeCallback);
            }

            videoAd.onClose(closeCallback);

            videoAd.onError(function (err) {
                switch (err.errCode) {
                    case -3:
                        console.log("激励广告加载失败---调用太频繁", JSON.stringify(err));
                        qg.showToast({
                            // message: "暂时没有合适的广告"
                        });
                        break;
                    case -4:
                        console.log("激励广告加载失败--- 一分钟内不能重复加载", JSON.stringify(err));
                        qg.showToast({
                            message: "暂时没有合适的广告"
                        });
                        break;
                    case 30008:
                        // 当前启动来源不支持激励视频广告，请选择其他激励策略
                        break;
                    default:
                        // 参考 https://minigame.vivo.com.cn/documents/#/lesson/open-ability/ad?id=广告错误码信息 对错误码做分类处理
                        console.log("激励广告展示失败")
                        console.log(JSON.stringify(err))
                        qg.showToast({
                            message: "暂时没有合适的广告"
                        });
                        break;
                }
                // console.log("fetch video error", err);
                // _callback && _callback(false, true, err);
            });

        }
        return videoAd;
    },

    createInsertAd: function (insertId) {
        // this.clearInsertAd();    
        let interstitialAd = qg.createInterstitialAd({
            posId: insertId,
            style: {}
        });
        let adShow = interstitialAd.show();
        // 调用then和catch之前需要对show的结果做下判空处理，防止出错（如果没有判空，在平台版本为1052以及以下的手机上将会出现错误）
        adShow && adShow.then(() => {
            console.log("插屏广告展示成功");
        }).catch((err) => {
            switch (err.code) {
                case 30003:
                    console.log("新用户7天内不能曝光Banner，请将手机时间调整为7天后，退出游戏重新进入")

                    break;
                case 30009:
                    console.log("10秒内调用广告次数超过1次，10秒后再调用")

                    setTimeout(() => {
                        show()
                    }, 10000);
                    break;
                case 30002:
                    console.log("load广告失败，重新加载广告")

                    setTimeout(() => {
                        retryShow()
                    }, 10000);
                    break;
                default:
                    // 参考 https://minigame.vivo.com.cn/documents/#/lesson/open-ability/ad?id=广告错误码信息 对错误码做分类处理
                    console.log("插屏广告展示失败")
                    console.log(JSON.stringify(err))
                    break;
            }
        });

    },
    clearInsertAd: function () {
        if (this.insertAd != null) {
            this.insertAd.destroy();
            this.insertAd = null;
            this.posId = null;
            console.log("清除了insertAd!!")
        }
    },

    //短震动
    vibrateShort: function () {
        if (qg.vibrateShort == null || this.isOpenVibration == false) return;
        qg.vibrateLong();
    },
    //长震动
    vibrateLong: function () {
        if (qg.vibrateLong == null || this.isOpenVibration == false) return;
        qg.vibrateLong();
    },

    //客服
    openCustomerServiceConversation: function (_param) {
        // if (qg.openCustomerServiceConversation == null) return;
        // qg.openCustomerServiceConversation(_param);
    },

    //开放数据
    setUserCloudStorage: function (_kvDataList) {

    },

    getUserCloudStorage: function (_kvDataList) {

    },

    createInnerAudioContext: function () {
        // if (qg.createInnerAudioContext) {
        //     return qg.createInnerAudioContext();
        // } else {
        //     return null;
        // }
    },

    getOpenDataContext: function () {
        // if (qg.getOpenDataContext) {
        //     return qg.getOpenDataContext();
        // } else {
        //     return null;
        // }
    },
    postMessage: function (_data) {
        // qg.postMessage(_data);
    },

    getSystemInfoSync: function () {
        // return qg.getSystemInfoSync();
    },

    //编码（名字表情）
    encode: function (_txt) {
        // return escape(_txt);
    },
    //解码（名字表情）
    decode: function (_txt) {
        // return unescape(_txt);
    }
};
if (!window["qg"]) {
    window.platform = null;
    console.log("没有qg环境(op,vivo)");
}
else {
    window.platform = new VOgamePlatform();
    console.log("初始化qg的环境");
}
