function OPgamePlatform() {
    console.log("op平台初始化！！")
    if(!qg)
    {
        console.log("没有qg环境")
        return
    }
    qg.initAdService({
        appId: "30208013",
        isDebug: false,
        success: function (res) {
            console.log("广告初始化success");
        },
        fail: function (res) {
            console.log("广告初始化fail:" + res.code + res.msg);
        },
        complete: function (res) {
            console.log("广告初始化complete");
        }
    })
    this.isOpenVibration=true;
}

OPgamePlatform.prototype = {
    constructor: OPgamePlatform,
    /**
       * 微信登陆。
       * 获取code。
       */
    login: function (cb) {
        qg.login({
            success: function (res) {
                console.log('登录成功',res);
            },

            fail: function (res) {
                console.log('登录失败：',res);
            }
        });
    },

    /**
  * 获取小游戏启动参数
  */
    launchInfo: function () {
        // return qg.getLaunchOptionsSync();
    },

    //获取玩家信息
    getUserInfo: function () {

    },

    //加载
    startLoading: function (_callback) {

    },
    onLoading: function (_percent) {

    },

    destroyButton: function () {

    },

    /**
    * 微信授权窗口
    * 透明的按钮，覆盖到某个节点上(通常是开始按钮)。
    * @param rect  覆盖的节点区域
    * @param cb  回调 
    */
    authorize: function (rect, cb) {

    },

    /**
     *  是否授权获取用户信息
     */
    isAuthorize: function (cb) {

    },

    hideAuthenticLoginBtn: function () {

    },

    //投诉建议按钮
    createFeedbackButton: function (_btnVect) {

    },

    //亮屏
    onShow: function (_callback) {

    },
    //黑屏
    onHide: function (_callback) {

    },

    //取两个数之间的随机数
    GetRandomNum: function (Min, Max) {

    },

    //分享
    onShare: function (_callback) {

    },

    //跳转小程序
    navigateToMiniProgram: function (_data) {

    },
    setLoadingProgress:function(value)
    {
        qg.setLoadingProgress({
            progress: value    
        });
    },
    loadingComplete:function(){
        qg.loadingComplete({
            success:function(res)
            {
                console.log("加载成功",res)
            },
            fail:function(err)
            {
                console.log("加载失败",err)
            },
            complete:function(res){
                console.log("加载完成",res)
            }
        })
    },
   

    createBannerAd: function (_adUnitId, func) {
        // if (this.bannerAd == null) {
            console.log("创建banner广告")
            var bannerAd = qg.createBannerAd({
                posId: _adUnitId,
            });

            console.log("bannerAd", bannerAd);
            // bannerAd.style.left = (systemInfoRes.windowWidth - targetBannerAdWidth) / 2;

            if (bannerAd) {
                bannerAd.show(console.log("banner加载"))
                bannerAd.onError(function (res) {
                    console.log("createBannerAd err", res);
                    bannerAd.offError();
                });
                bannerAd.onShow(function () {
                    console.log("banner 广告显示");
                    bannerAd.offShow();
                  
                });
            }
            this.bannerAd = bannerAd;
            return bannerAd;
        // }
    },
    closeBannerAd: function () {
        console.log("调用了clear banner！！！");
        if (!this.bannerAd) return;
        console.log("clear了banner！！！");
        this.bannerAd.destroy();
        this.bannerAd = null;
        
    },

    setBannerVisible: function (visible) {
        if (!this.bannerAd) return;
        if (visible) {
            this.bannerAd.show();
            console.log("show!!!!!!!!!!!!!!!")
        }
        else {
            this.bannerAd.hide();
            console.log("hide!!!!!!!!!!!!!!!")
        }
    },

    //视频广告 preload 是否预加载，预加载不播放视频
    createRewardedVideoAd: function (_adUnitId, _callback, preload) {
        if (typeof (window["qg"].createRewardedVideoAd) == "undefined") {
            console.log("要真机调试才能测试头条的激励视频！！");
            return;
        }
        var videoAd = qg.createRewardedVideoAd({ posId: _adUnitId });
        if (videoAd) {

            videoAd.load();
            videoAd.onLoad(function () {
                console.log("激励视频加载成功");
                videoAd.show();
            })
            var closeCallback = function (res) {

                // 用户点击了关闭广告按钮
                if (res && res.isEnded) {
                    // 正常播放结束，可以下发游戏奖励
                    _callback && _callback(true);
                    console.log("正常播放结束，可以下发游戏奖励")
                }
                else {
                    // 播放中途退出，不下发游戏奖励
                    _callback && _callback(false);
                    console.log("播放中途退出，不下发游戏奖励")
                }
                videoAd.offClose(closeCallback);
            }

            videoAd.onClose(closeCallback);

            videoAd.onError(function (res) {
                console.log("fetch video error", res);
                _callback && _callback(false, true, res);
            });

        }
        return videoAd;
    },

    createInsertAd: function (_adUnitId) {
        // this.clearInsertAd();    
        var insertAd = qg.createInsertAd({
            posId: _adUnitId
        });
        insertAd.load();
        insertAd.onLoad(function () {
            console.log("插屏广告加载");
            insertAd.show();
            insertAd.offLoad();
        });
        insertAd.onShow(function () {
            console.log("插屏广告展示成功");
            insertAd.offShow();

        })
        insertAd.onError(function (err) {
            console.log("插屏广告展示失败", err);
            insertAd.offError();
        })

    },
    clearInsertAd: function ()  {
        if (this.insertAd != null)  {
            this.insertAd.destroy();
            this.insertAd = null;
            this.posId = null;
            console.log("清除了insertAd!!")
        }
    },

   //短震动
    vibrateShort: function () {
        if (qg.vibrateShort == null || this.isOpenVibration == false) return;
        qg.vibrateShort({
            success: function () {
                // console.log("vibrateShort success");
            },
            fail: function () {
                console.log("vibrateShort fail");
            },
            complete: function () {
                // console.log("vibrate complete");
            }
        });
    },
    //长震动
    vibrateLong: function () {
        if (qg.vibrateLong == null || this.isOpenVibration == false) return;
        qg.vibrateLong({});
    },

    //客服
    openCustomerServiceConversation: function (_param) {
        // if (qg.openCustomerServiceConversation == null) return;
        // qg.openCustomerServiceConversation(_param);
    },

    //开放数据
    setUserCloudStorage: function (_kvDataList) {

    },

    getUserCloudStorage: function (_kvDataList) {

    },

    createInnerAudioContext: function () {
        // if (qg.createInnerAudioContext) {
        //     return qg.createInnerAudioContext();
        // } else {
        //     return null;
        // }
    },

    getOpenDataContext: function () {
        // if (qg.getOpenDataContext) {
        //     return qg.getOpenDataContext();
        // } else {
        //     return null;
        // }
    },
    postMessage: function (_data) {
        // qg.postMessage(_data);
    },

    getSystemInfoSync: function () {
        // return qg.getSystemInfoSync();
    },

    //编码（名字表情）
    encode: function (_txt) {
        // return escape(_txt);
    },
    //解码（名字表情）
    decode: function (_txt) {
        // return unescape(_txt);
    }
};

window.platform = new OPgamePlatform();
